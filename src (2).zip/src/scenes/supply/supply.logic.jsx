// ─────────────────────────────────────────────────────────────────────────────
// useSupply.js  –  All state, derived values, handlers, and export utilities
//                  for the SupplyPage. No JSX lives here.
// ─────────────────────────────────────────────────────────────────────────────

import { useState, useMemo, useEffect, useRef } from "react";
import { hasPermission, isAdminOrSuper, isSuperAdmin } from "../../utils/auth";
import { notifySupplyChanged } from "../../utils/eventbus";
import PictureAsPdfOutlinedIcon from "@mui/icons-material/PictureAsPdfOutlined";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";
import TableChartOutlinedIcon from "@mui/icons-material/TableChartOutlined";
import InsertDriveFileOutlinedIcon from "@mui/icons-material/InsertDriveFileOutlined";
import {
  API_BASE, canRecordTransfers,
  fetchOwedList, repayOwed,
} from "./supply.owed";


// NOTE: the TRANSFER_REQUIRES_ADMIN switch (who may take stock from another
// client / record repayments) now lives in supply.owed.jsx, shared with Store.

// ══════════════════════════════════════════════════════════════════════════════
// BACKEND GUIDE — TAKING STOCK FROM ANOTHER CLIENT  ("owed" ledger)
// ══════════════════════════════════════════════════════════════════════════════
// Scenario: stock is held in the store for Client A. You supply it to Client B
// instead. A's stock is gone, so A must be replaced later → "we owe A".
//
// Design: an APPEND-ONLY LEDGER. Never keep a bare number you edit in place —
// every change is a row, and "owed" is calculated by adding the rows up. That
// gives you history (who/when/why) and makes mistakes reversible.
//
// ── 1. NEW COLLECTION / TABLE: supplyLedger ──────────────────────────────────
//   {
//     _id,
//     client:        ref Client   // the client who is OWED (the one taken FROM)
//     partNumber:    String       // trim + uppercase before saving, so
//                                 // "pr-1001 " and "PR-1001" are the same part
//     goodsSupplied: String       // description, for display
//     qtyChange:     Number       // NEGATIVE = taken (we owe more)
//                                 // POSITIVE = repaid / reversed (we owe less)
//     type:          "borrowed_out" | "settled" | "reversed"
//     relatedSupply: ref Supply   // the supply entry that caused it (if any)
//     note:          String       // reason (required for borrowed_out)
//     createdBy:     ref User     // from the TOKEN, never from the request body
//     createdAt:     Date
//   }
//   Index:  { client: 1, partNumber: 1 }  and  { relatedSupply: 1 }
//   NEVER update or delete ledger rows. Corrections = a new row.
//
// ── 2. ADD TO THE EXISTING Supply model ──────────────────────────────────────
//   takenFrom:    ref Client (optional)   // set only when stock came from another client
//   transferNote: String     (optional)
//
// ── 3. CHANGE  POST /supply  (multipart, currently multer) ───────────────────
//   New optional text fields in the form data:  takenFromClientId, transferNote.
//   If takenFromClientId is present:
//     a) PERMISSION: only administrator / superadmin (mirror
//        TRANSFER_REQUIRES_ADMIN in supply.owed.jsx). Otherwise 403 { message }.
//     b) VALIDATE: client exists; it is NOT the same as clientId (the client
//        receiving it); transferNote is non-empty (max ~300 chars).
//     c) In ONE database transaction:
//          i.  insert the Supply row (with takenFrom + transferNote)
//          ii. insert a ledger row:
//              { client: takenFromClientId, partNumber, goodsSupplied,
//                qtyChange: -quantity, type: "borrowed_out",
//                relatedSupply: supply._id, note: transferNote,
//                createdBy: req.user._id }
//        (MongoDB transactions need a replica set. If you can't use one, insert
//         the ledger row first, then the supply, and delete the ledger row if
//         the supply insert fails.)
//   If takenFromClientId is absent, behave exactly as today.
//   The response row must now include  takenFrom  populated as
//   { _id, id, companyName } (or null) — the table shows it in a column.
//   Likewise GET /supply must populate takenFrom on every row.
//
// ── 4. NEW ROUTE:  GET /supply/owed ──────────────────────────────────────────
//   Returns what is currently owed, aggregated from the ledger. Users with the
//   "supply" OR "store" permission may read it (the Store page shows it too).
//   Response: array of
//     { client: { _id, id, companyName }, partNumber, goodsSupplied,
//       owed: Number /* positive */, lastTakenAt: Date }
//   Only include groups whose total is below zero. (A total at or above zero
//   means nothing is owed. It can go positive if a supply entry is deleted
//   AFTER part of it was repaid — i.e. the client was over-repaid. Just hide
//   those; don't show a negative "owed".) Mongoose pipeline:
//
//     SupplyLedger.aggregate([
//       { $group: {
//           _id:   { client: "$client", partNumber: "$partNumber" },
//           total: { $sum: "$qtyChange" },
//           goodsSupplied: { $last: "$goodsSupplied" },
//           lastTakenAt: { $max: { $cond: [{ $eq: ["$type", "borrowed_out"] }, "$createdAt", null] } },
//       }},
//       { $match: { total: { $lt: 0 } } },
//       { $project: { client: "$_id.client", partNumber: "$_id.partNumber",
//                     goodsSupplied: 1, lastTakenAt: 1, owed: { $multiply: ["$total", -1] } } },
//     ])
//     // then populate client { companyName } before responding
//
// ── 5. NEW ROUTE:  POST /supply/owed/repay ───────────────────────────────────
//   Body: { clientId, partNumber, quantity, note }
//   - Same permission rule as step 3a.
//   - Recalculate the current owed for (clientId, partNumber) INSIDE the
//     transaction and reject (400) if quantity <= 0 or quantity > owed, so two
//     people repaying at once can't overpay.
//   - Insert a ledger row: { qtyChange: +quantity, type: "settled", note,
//     createdBy: req.user._id }. Respond 201 { message }.
//
// ── 6. WHEN A SUPPLY ENTRY IS DELETED (DELETE /supply/:id and /bulk-delete) ──
//   If the supply had takenFrom set, ALSO insert a compensating ledger row for
//   each linked borrowed_out row:  { qtyChange: +(that row's absolute qty),
//   type: "reversed", relatedSupply: id, note: "Supply entry deleted" }.
//   Do it in the same transaction as the delete. Do NOT delete the original
//   ledger rows — the history stays intact and the net owed goes back to
//   what it was.
//
// ── 7. EXCEL / BULK IMPORT HAS MOVED TO THE STORE PAGE ──────────────────────
//   The Supply page no longer imports from Excel (no POST /supply/bulk).
//   Bulk upload now lives in scenes/store (POST /store/bulk).
//
// ── 8. LATER (when the Store tracks stock PER CLIENT) ────────────────────────
//   Today the Store has one quantity per part with no client, so every take is
//   treated as owed until replaced. Once the Store knows which client a unit
//   belongs to:
//     - when taking from A, first use A's held stock and only the SHORTFALL
//       becomes a borrowed_out ledger row;
//     - when stock for A is restocked (POST /store or PATCH /store/:id/quantity
//       with clientId = A), auto-settle: compute A's owed for that part and
//       insert a "settled" row for min(owed, restocked quantity).
//   Keep the Store's physical quantity clamped at 0 (it can't be negative).
//   Only the owed figure is a claim, and it comes from this ledger.
// ══════════════════════════════════════════════════════════════════════════════

// ── auth headers ──────────────────────────────────────────────────────────────
// IMPORTANT: never include Content-Type when sending FormData — the browser
// must set the multipart boundary itself or multer will reject the request.
const authBearer = () => ({
  Authorization: `Bearer ${localStorage.getItem("token")}`,
});

const authJson = () => ({
  "Content-Type": "application/json",
  Authorization: `Bearer ${localStorage.getItem("token")}`,
});

// ── safeJson ──────────────────────────────────────────────────────────────────
// Safely parses a fetch Response as JSON.  If the server returns HTML (e.g. a
// crash page, a 502 from a proxy, or multer not yet installed) `.json()` would
// normally throw "JSON.parse: unexpected character at line 1 column 1".
// This helper swallows that and returns a plain object instead so callers can
// always do `data.message` without crashing.
const safeJson = async (res) => {
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    // Server returned non-JSON (HTML error page, plain-text, etc.)
    // Surface the raw text in development so it's easy to diagnose.
    console.error("[supply] Non-JSON response from server:", text.slice(0, 300));
    return { message: "Server returned an unexpected response. Check the backend console." };
  }
};

// ── export helpers ────────────────────────────────────────────────────────────

export const exportCSV = (rows) => {
  const headers = [
    "ID", "Goods Supplied", "Serial Number", "Part Number", "Qty",
    "Client", "Supply Date", "Taken From", "Transfer Note", "Logged By", "Attachments",
  ];
  const data = rows.map((r) => [
    r.id ?? r._id,
    r.goodsSupplied,
    r.serialNumber ?? "",
    r.partNumber,
    r.quantity,
    r.client?.companyName ?? "",
    r.supplyDate,
    r.takenFrom?.companyName ?? "",
    r.transferNote ?? "",
    r.user ? `${r.user.firstName} ${r.user.surname}` : "",
    (r.attachments || []).map((f) => f.name).join("; "),
  ]);
  const content = [headers, ...data]
    .map((row) => row.map((v) => `"${v}"`).join(","))
    .join("\n");
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `zutrad_supply_${new Date().toISOString().slice(0, 10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
};

export const exportJSON = (rows) => {
  const serializable = rows.map((r) => ({
    ...r,
    attachments: (r.attachments || []).map((f) => f.name),
  }));
  const blob = new Blob([JSON.stringify(serializable, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `zutrad_supply_${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
};

// ── file-type icon resolver ───────────────────────────────────────────────────

export const fileIcon = (filename) => {
  const ext = (filename ?? "").split(".").pop()?.toLowerCase();
  if (ext === "pdf")                   return PictureAsPdfOutlinedIcon;
  if (ext === "doc" || ext === "docx") return DescriptionOutlinedIcon;
  if (ext === "xls" || ext === "xlsx") return TableChartOutlinedIcon;
  return InsertDriveFileOutlinedIcon;
};

// ── FORM INITIAL STATE ────────────────────────────────────────────────────────

const EMPTY_FORM = {
  goodsSupplied: "",
  serialNumber: "", // must match a part in the Store; stock is deducted from it
  partNumber: "",
  quantity: "",
  supplyDate: "",
  clientId: "",
  takenFromClientId: "", // optional: stock was taken from THIS client's holding
  transferNote: "",      // required when takenFromClientId is set
};

// ── main hook ─────────────────────────────────────────────────────────────────

export const useSupply = () => {

  // ── permission flags ───────────────────────────────────────────────────────
  const canLogSupply = hasPermission("supply");
  const canDelete    = isSuperAdmin();
  const canExport    = isAdminOrSuper();
  const canDownload  = isAdminOrSuper(); // download attachments
  // Taking stock from another client / repaying what is owed
  const canTransfer  = canRecordTransfers();

  // ── core data ───────────────────────────────────────────────────────────────
  const [rows,        setRows]        = useState([]);
  const [clients,     setClients]     = useState([]); // real clients from GET /clients
  const [loading,     setLoading]     = useState(true);
  const [loadError,   setLoadError]   = useState("");
  const [selectedIds, setSelectedIds] = useState([]);

  // ── owed-to-clients state ───────────────────────────────────────────────────
  // owed: [{ client, partNumber, goodsSupplied, owed, lastTakenAt }]
  const [owed,       setOwed]       = useState([]);
  const [owedOpen,   setOwedOpen]   = useState(false);
  const [repayDialog, setRepayDialog] = useState({ open: false, item: null, quantity: "", note: "", error: "" });
  const [repaying,   setRepaying]   = useState(false);

  // ── ui state ────────────────────────────────────────────────────────────────
  const [formOpen, setFormOpen] = useState(false);
  const [toast,    setToast]    = useState({ open: false, message: "", severity: "success" });

  // ── error / access-denied dialog ──────────────────────────────────────────
  const [errorDialog, setErrorDialog] = useState({ open: false, title: "", message: "" });
  const closeErrorDialog = () => setErrorDialog({ open: false, title: "", message: "" });
  const showErrorDialog  = (title, message) => setErrorDialog({ open: true, title, message });

  const [confirmDialog, setConfirmDialog] = useState({ open: false, title: "", message: "" });
  const confirmDialogAction = useRef(null);
  const closeConfirmDialog = () => {
    setConfirmDialog({ open: false, title: "", message: "" });
    confirmDialogAction.current = null;
  };
  const submitConfirmDialog = async () => {
    if (confirmDialogAction.current) {
      await confirmDialogAction.current();
    }
    closeConfirmDialog();
  };

  const openFormIfAuthorised = () => {
    if (!canLogSupply) {
      showErrorDialog(
        "Access Denied",
        "You don't have permission to log supply. Ask an administrator to grant you supply access."
      );
      return;
    }
    setFormOpen(true);
  };

  // ── download confirmation dialog ───────────────────────────────────────────
  const [downloadDialog, setDownloadDialog] = useState({ open: false, file: null });
  const closeDownloadDialog = () => setDownloadDialog({ open: false, file: null });

  const handleFileClick = (file) => {
    if (!canDownload) {
      showErrorDialog(
        "Access Denied",
        "Only administrators and superadmins can download attachments."
      );
      return;
    }
    setDownloadDialog({ open: true, file });
  };

  const handleDownloadConfirm = async () => {
    const { name, storedName } = downloadDialog.file ?? {};
    closeDownloadDialog();

    if (!storedName) {
      // Legacy entry saved before the file-upload feature was added —
      // it only has a display name, no stored file on disk.
      showErrorDialog(
        "File Not Available",
        "This attachment was logged before file uploads were enabled and has no stored file to download."
      );
      return;
    }

    try {
      const res = await fetch(
        `${API_BASE}/supply/files/${encodeURIComponent(storedName)}`,
        { headers: authBearer() }
      );

      if (!res.ok) {
        // Error responses from our API are JSON; guard with safeJson
        const body = await safeJson(res);
        throw new Error(body.message || `Download failed (${res.status}).`);
      }

      // Success — the response is the raw file binary, not JSON
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement("a");
      a.href     = url;
      a.download = name ?? storedName;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      showErrorDialog("Download Failed", err.message);
    }
  };

  // ── filter state ────────────────────────────────────────────────────────────
  const [search,       setSearch]       = useState("");
  const [clientFilter, setClientFilter] = useState("all");

  // ── form state ──────────────────────────────────────────────────────────────
  const [form,        setForm]        = useState(EMPTY_FORM);
  const [formError,   setFormError]   = useState("");
  const [submitting,  setSubmitting]  = useState(false);
  const [attachments, setAttachments] = useState([]); // File[] from <input type="file">

  // ── toast helpers ──────────────────────────────────────────────────────────
  const showToast = (message, severity = "success") =>
    setToast({ open: true, message, severity });
  const closeToast = () => setToast((t) => ({ ...t, open: false }));

  // ── fetch supply rows on mount ──────────────────────────────────────────────
  const fetchRows = async () => {
    setLoading(true);
    setLoadError("");
    try {
      const res  = await fetch(`${API_BASE}/supply`, { headers: authBearer() });
      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.message || "Failed to load supply log.");
      setRows(data);
    } catch (err) {
      setLoadError(err.message);
      showToast(err.message, "error");
    } finally {
      setLoading(false);
    }
  };

  // Real client list for the dropdowns. `id` mirrors Mongo's `_id` so the rest
  // of the page can keep reading `c.id`.
  const fetchClients = async () => {
    try {
      const res  = await fetch(`${API_BASE}/clients`, { headers: authBearer() });
      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.message || "Failed to load clients.");
      setClients((Array.isArray(data) ? data : []).map((c) => ({ ...c, id: c._id ?? c.id })));
    } catch (err) {
      showToast(err.message, "error");
    }
  };

  // Aggregated "we owe these clients" list — GET /supply/owed (guide step 4)
  const fetchOwed = async () => {
    try {
      setOwed(await fetchOwedList());
    } catch (err) {
      showToast(err.message, "error");
    }
  };

  useEffect(() => {
    fetchRows();
    fetchOwed();
    fetchClients();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── derived stats ─────────────────────────────────────────────────────────
  const totalQty      = rows.reduce((acc, r) => acc + (Number(r.quantity) || 0), 0);
  const uniqueClients = new Set(rows.map((r) => r.client?.id ?? r.client?._id)).size;
  const totalOwed     = owed.reduce((acc, o) => acc + (Number(o.owed) || 0), 0);

  // ── filtered rows ─────────────────────────────────────────────────────────
  const filteredRows = useMemo(() => {
    return rows.filter((r) => {
      const q = search.toLowerCase();
      const matchSearch =
        !q ||
        r.goodsSupplied?.toLowerCase().includes(q) ||
        r.partNumber?.toLowerCase().includes(q) ||
        r.serialNumber?.toLowerCase().includes(q) ||
        r.client?.companyName?.toLowerCase().includes(q) ||
        (r.user ? `${r.user.firstName} ${r.user.surname}` : "").toLowerCase().includes(q);
      const matchClient =
        clientFilter === "all" || String(r.client?.id ?? r.client?._id) === clientFilter;
      return matchSearch && matchClient;
    });
  }, [rows, search, clientFilter]);

  // ── form handlers ─────────────────────────────────────────────────────────

  const handleChange = (e) => {
    setFormError("");
    const { name, value } = e.target;
    setForm((prev) => {
      const next = { ...prev, [name]: value };
      // The client receiving the goods can't also be the one taken from
      if (name === "clientId" && String(value) === String(prev.takenFromClientId)) {
        next.takenFromClientId = "";
        next.transferNote = "";
      }
      if (name === "takenFromClientId" && !value) next.transferNote = "";
      return next;
    });
  };

  const handleFileChange = (e) => {
    setAttachments(Array.from(e.target.files || []));
  };

  const resetForm = () => {
    setForm(EMPTY_FORM);
    setAttachments([]);
    setFormError("");
  };

  // ── submit — multipart/form-data so files are actually uploaded ────────────
  // DO NOT set Content-Type header — the browser sets it with the correct
  // multipart boundary automatically when the body is a FormData instance.
  // Setting it manually breaks multer's parser on the server.
  const handleSubmit = async () => {
    if (!canLogSupply) {
      showErrorDialog(
        "Access Denied",
        "You don't have permission to log supply. Ask an administrator to grant you supply access."
      );
      return;
    }

    const { goodsSupplied, serialNumber, partNumber, quantity, supplyDate, clientId, takenFromClientId, transferNote } = form;
    if (!goodsSupplied.trim()) { setFormError("Goods Supplied is required."); return; }
    if (!serialNumber.trim())  { setFormError("Serial Number is required.");  return; }
    if (!partNumber.trim())    { setFormError("Part Number is required.");    return; }
    if (!quantity || Number(quantity) <= 0) { setFormError("Enter a valid quantity."); return; }
    if (!supplyDate)           { setFormError("Supply Date is required.");    return; }
    if (!clientId)             { setFormError("Please select a client.");     return; }

    if (takenFromClientId) {
      if (!canTransfer) {
        showErrorDialog("Access Denied", "Only administrators and superadmins can take stock from another client.");
        return;
      }
      if (String(takenFromClientId) === String(clientId)) { setFormError("\"Taken from\" must be a different client."); return; }
      if (!transferNote.trim()) { setFormError("Add a note explaining why stock was taken from another client."); return; }
    }

    setSubmitting(true);
    try {
      const fd = new FormData();
      fd.append("goodsSupplied", goodsSupplied);
      fd.append("serialNumber",  serialNumber.trim());
      fd.append("partNumber",    partNumber);
      fd.append("quantity",      quantity);
      fd.append("supplyDate",    supplyDate);
      fd.append("clientId",      clientId);
      if (takenFromClientId) {
        fd.append("takenFromClientId", takenFromClientId);
        fd.append("transferNote",      transferNote.trim());
      }
      // Append each File object under the key "files" — multer's
      // upload.array("files") picks them all up on the server side.
      attachments.forEach((file) => fd.append("files", file));

      const res  = await fetch(`${API_BASE}/supply`, {
        method:  "POST",
        headers: authBearer(), // no Content-Type — critical for multipart
        body:    fd,
      });
      const data = await safeJson(res);
      if (!res.ok) throw new Error(data.message || "Failed to add supply log.");

      setRows((prev) => [data, ...prev]);
      if (takenFromClientId) fetchOwed(); // a new "owed" record was created server-side
      notifySupplyChanged();
      resetForm();
      setFormOpen(false);
      showToast("Supply log added successfully.");
    } catch (err) {
      setFormError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancelForm = () => {
    setFormOpen(false);
    resetForm();
  };

  // ── delete handlers ───────────────────────────────────────────────────────

  const handleDelete = (id) => {
    if (!canDelete) {
      showErrorDialog(
        "Access Denied",
        "Only superadmins can delete entries. Contact your superadmin if you need this action performed."
      );
      return;
    }

    setConfirmDialog({
      open: true,
      title: "Delete supply entry?",
      message: "Delete this supply entry? This cannot be undone.",
    });
    confirmDialogAction.current = async () => {
      try {
        const res  = await fetch(`${API_BASE}/supply/${id}`, {
          method:  "DELETE",
          headers: authBearer(),
        });
        const data = await safeJson(res);
        if (!res.ok) throw new Error(data.message || "Failed to delete entry.");
        setRows((prev) => prev.filter((r) => r._id !== id));
        fetchOwed(); // server reversed any linked "owed" record
        notifySupplyChanged();
        showToast("Entry deleted.");
      } catch (err) {
        showToast(err.message, "error");
      }
    };
  };

  const handleBulkDelete = () => {
    if (!canDelete) {
      showErrorDialog(
        "Access Denied",
        "Only superadmins can delete entries. Contact your superadmin if you need this action performed."
      );
      return;
    }

    setConfirmDialog({
      open: true,
      title: "Delete selected entries?",
      message: `Delete ${selectedIds.length} selected entries? This cannot be undone.`,
    });
    confirmDialogAction.current = async () => {
      try {
        const res  = await fetch(`${API_BASE}/supply/bulk-delete`, {
          method:  "POST",
          headers: authJson(),
          body:    JSON.stringify({ ids: selectedIds }),
        });
        const data = await safeJson(res);
        if (!res.ok) throw new Error(data.message || "Failed to delete entries.");
        setRows((prev) => prev.filter((r) => !selectedIds.includes(r._id)));
        fetchOwed();
        notifySupplyChanged();
        showToast(data.message || `${selectedIds.length} entries deleted.`);
        setSelectedIds([]);
      } catch (err) {
        showToast(err.message, "error");
      }
    };
  };

  // ── repaying what is owed ─────────────────────────────────────────────────
  // POST /supply/owed/repay { clientId, partNumber, quantity, note } (guide step 5)
  const openRepay = (item) => {
    if (!canTransfer) {
      showErrorDialog("Access Denied", "Only administrators and superadmins can record repayments.");
      return;
    }
    setRepayDialog({ open: true, item, quantity: String(item.owed), note: "", error: "" });
  };

  const closeRepay = () => {
    if (repaying) return;
    setRepayDialog({ open: false, item: null, quantity: "", note: "", error: "" });
  };

  const changeRepay = (field, value) =>
    setRepayDialog((d) => ({ ...d, [field]: value, error: "" }));

  const confirmRepay = async () => {
    const { item, quantity, note } = repayDialog;
    const qty = Number(quantity);
    if (!Number.isFinite(qty) || qty <= 0) { changeRepay("error", "Enter a quantity above 0."); return; }
    if (qty > item.owed) { setRepayDialog((d) => ({ ...d, error: `You only owe ${item.owed}. Enter ${item.owed} or less.` })); return; }

    setRepaying(true);
    try {
      const clientId = item.client?.id ?? item.client?._id;
      await repayOwed({
        clientId,
        partNumber: item.partNumber,
        goodsSupplied: item.goodsSupplied,
        quantity: qty,
        note: note.trim(),
      });
      await fetchOwed();
      setRepayDialog({ open: false, item: null, quantity: "", note: "", error: "" });
      showToast(`Repayment of ${qty} recorded.`);
    } catch (err) {
      setRepayDialog((d) => ({ ...d, error: err.message }));
    } finally {
      setRepaying(false);
    }
  };

  // ── clear filters ─────────────────────────────────────────────────────────
  const clearFilters = () => {
    setSearch("");
    setClientFilter("all");
  };

  // ── gated export handlers — admin/superadmin only ─────────────────────────
  const handleExportCSV = () => {
    if (!canExport) {
      showErrorDialog("Access Denied", "Only administrators and superadmins can export data.");
      return;
    }
    exportCSV(filteredRows);
  };

  const handleExportJSON = () => {
    if (!canExport) {
      showErrorDialog("Access Denied", "Only administrators and superadmins can export data.");
      return;
    }
    exportJSON(filteredRows);
  };

  // ── exposed API ───────────────────────────────────────────────────────────
  return {
    // data
    rows,
    filteredRows,
    selectedIds,
    setSelectedIds,
    loading,
    loadError,
    clients,

    // stats
    totalQty,
    uniqueClients,

    // filters
    search,
    setSearch,
    clientFilter,
    setClientFilter,
    clearFilters,

    // form
    form,
    formOpen,
    setFormOpen,
    openFormIfAuthorised,
    formError,
    submitting,
    attachments,
    setAttachments,
    handleChange,
    handleFileChange,
    handleSubmit,
    handleCancelForm,

    // delete
    handleDelete,
    handleBulkDelete,
    confirmDialog,
    closeConfirmDialog,
    submitConfirmDialog,

    // export
    handleExportCSV,
    handleExportJSON,

    // file download
    handleFileClick,
    downloadDialog,
    closeDownloadDialog,
    handleDownloadConfirm,

    // toast
    toast,
    closeToast,

    // error / access-denied dialog
    errorDialog,
    closeErrorDialog,

    // owed to clients (stock taken from another client's holding)
    owed,
    totalOwed,
    owedOpen,
    setOwedOpen,
    repayDialog,
    repaying,
    openRepay,
    closeRepay,
    changeRepay,
    confirmRepay,
    canTransfer,

    // preview mode flag

    // permissions
    canLogSupply,
    canDelete,
    canExport,
    canDownload,
  };
};